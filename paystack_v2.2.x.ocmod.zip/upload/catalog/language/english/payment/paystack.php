<?php
// Text
$_['text_title'] = 'Paystack';
$_['text_testmode'] = 'Warning: The payment gateway is in \'Test Mode\'. Only a  test card can be used.';
